#define MAX_STEPS 10000
int getDecryptionFromUser(int min, int max);