char* getOperation(char *line);
void printCommands();