#ifndef SOLVER_H
#define SOLVER_H

int breadthFirst(maze_t* maze);

#endif
